import boto3

def lambda_handler(event, context):
    # Extract bucket name from S3 event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    # Extract filename from the S3 event
    filename = event['Records'][0]['s3']['object']['key']

    client = boto3.client('ecs')
    response = client.run_task(
        cluster='single_site_report_app_cluster',
        launchType='FARGATE',
        taskDefinition='single_site_report_app_task_definition',
        count=1,
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': ['SUBNET_ID_1', 'SUBNET_ID_2'],
                'assignPublicIp': 'ENABLED'
            }
        },
        overrides={
            'containerOverrides': [{
                'name': 'single_site_report_app_container',
                'environment': [
                    {
                        'name': 'FILENAME',
                        'value': filename
                    },
                    {
                        'name': 'BUCKET_NAME',
                        'value': bucket_name
                    }
                ]
            }]
        }
    )
    return response